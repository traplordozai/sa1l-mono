import React from "react";

const MatchingRoundList = () => {
  return <div className="border p-4 rounded">List of Matching Rounds</div>;
};

export default MatchingRoundList;