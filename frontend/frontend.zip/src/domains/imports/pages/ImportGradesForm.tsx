import React from "react";

const ImportGradesForm = () => {
  return <div>Import grades via upload (not yet wired)</div>;
};

export default ImportGradesForm;