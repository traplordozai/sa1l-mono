export default function ProfilePage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Profile Page</h1>
      <p>Work in progress...</p>
    </div>
  )
}
