import React from "react";

const StudentGradesPDFImport = () => {
  return (
    <div className="border p-4 rounded">
      <h3 className="font-bold">PDF Upload (Grades)</h3>
      <input type="file" />
    </div>
  );
};

export default StudentGradesPDFImport;