export default function ReviewsPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Reviews Page</h1>
      <p>Work in progress...</p>
    </div>
  )
}
